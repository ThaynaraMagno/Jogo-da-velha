import pygame
from tabuleiro import Tabuleiro

buttons_v = pygame.sprite.Group()

class Button(pygame.sprite.Sprite):
    def __init__(self, screen, position, dim):
        super().__init__()
        self.fg = "black"
        self.bg = "white"

        self.x, self.y = position
        self.w, self.h = dim
        self.rect = pygame.Rect(self.x, self.y, self.w, self.h)
        self.screen = screen
        self.jogador = Tabuleiro.DESCONHECIDO

        self.font = pygame.font.SysFont("Arial", 150)
        self.text_render = self.font.render(" ", True, pygame.Color(self.fg))

        self.image = pygame.Surface((self.w, self.h))
        self.image.fill(pygame.Color(self.bg))
        self.image.blit(self.text_render, (0, 0))

        buttons_v.add(self)

    def change_text(self, jogador):
        if self.jogador != Tabuleiro.DESCONHECIDO:
            return

        self.jogador = jogador

        texto = "O" if jogador == Tabuleiro.JOGADOR_0 else "X"
        self.text_render = self.font.render(texto, True, pygame.Color(self.fg))
        self.update()

    def update(self):
        self.image.fill(pygame.Color(self.bg))
        text_rect = self.text_render.get_rect(center=(self.w // 2, self.h // 2))
        self.image.blit(self.text_render, text_rect)
