from tabuleiro import Tabuleiro

class Jogador:
    def __init__(self, tabuleiro: Tabuleiro, tipo: int):
        self.tabuleiro = tabuleiro
        self.matriz = tabuleiro.matriz
        self.tipo = tipo

    def getJogada(self):
        pass
