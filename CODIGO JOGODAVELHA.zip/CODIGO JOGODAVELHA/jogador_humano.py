import pygame
from jogador import Jogador
from tabuleiro import Tabuleiro

class JogadorHumano(Jogador):
    def __init__(self, tabuleiro, buttons, tipo):
        super().__init__(tabuleiro, tipo)
        self.buttons = buttons

    def getJogada(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    for i in range(3):
                        for j in range(3):
                            if self.buttons[i][j].rect.collidepoint(pos):
                                if self.matriz[i][j] == Tabuleiro.DESCONHECIDO:
                                    return (i, j)
