from jogador import Jogador
from tabuleiro import Tabuleiro

class JogadorIA(Jogador):
    def __init__(self, tabuleiro, tipo):
        super().__init__(tabuleiro, tipo)
        self.oponente = Tabuleiro.JOGADOR_X if tipo == Tabuleiro.JOGADOR_0 else Tabuleiro.JOGADOR_0

    def getJogada(self):
        # R1 - Tenta vencer
        jogada = self.jogar_duas_em_sequencia(self.tipo)
        if jogada:
            return jogada
        
        # R1 - Tenta bloquear o oponente
        jogada = self.jogar_duas_em_sequencia(self.oponente)
        if jogada:
            return jogada
        
        # R2 - Cria fork
        jogada = self.jogar_fork(self.tipo)
        if jogada:
            return jogada
        
        # R3 - Marca o centro se livre
        if self.matriz[1][1] == Tabuleiro.DESCONHECIDO:
            return (1, 1)
        
        # R4 - Marca canto oposto ao do oponente
        jogada = self.jogar_canto_oposto()
        if jogada:
            return jogada
        
        # R5 - Marca qualquer canto vazio
        jogada = self.jogar_canto_vazio()
        if jogada:
            return jogada
        
        # R6 - Marca qualquer posição vazia
        return self.jogar_qualquer()

    def jogar_duas_em_sequencia(self, jogador):
        m = self.matriz
        for i in range(3):
            # Linhas
            if m[i].count(jogador) == 2 and m[i].count(Tabuleiro.DESCONHECIDO) == 1:
                return (i, m[i].index(Tabuleiro.DESCONHECIDO))
            # Colunas
            col = [m[0][i], m[1][i], m[2][i]]
            if col.count(jogador) == 2 and col.count(Tabuleiro.DESCONHECIDO) == 1:
                return (col.index(Tabuleiro.DESCONHECIDO), i)
        
        # Diagonais
        diag1 = [m[0][0], m[1][1], m[2][2]]
        if diag1.count(jogador) == 2 and diag1.count(Tabuleiro.DESCONHECIDO) == 1:
            idx = diag1.index(Tabuleiro.DESCONHECIDO)
            return (idx, idx)
        
        diag2 = [m[0][2], m[1][1], m[2][0]]
        if diag2.count(jogador) == 2 and diag2.count(Tabuleiro.DESCONHECIDO) == 1:
            idx = diag2.index(Tabuleiro.DESCONHECIDO)
            return (idx, 2 - idx)
        
        return None

    def jogar_fork(self, jogador):
        for i in range(3):
            for j in range(3):
                if self.matriz[i][j] == Tabuleiro.DESCONHECIDO:
                    self.matriz[i][j] = jogador
                    count = self.contar_duas_em_sequencia(jogador)
                    self.matriz[i][j] = Tabuleiro.DESCONHECIDO
                    if count >= 2:
                        return (i, j)
        return None

    def contar_duas_em_sequencia(self, jogador):
        m = self.matriz
        count = 0
        for i in range(3):
            linha = m[i]
            if linha.count(jogador) == 2 and linha.count(Tabuleiro.DESCONHECIDO) == 1:
                count += 1

            coluna = [m[0][i], m[1][i], m[2][i]]
            if coluna.count(jogador) == 2 and coluna.count(Tabuleiro.DESCONHECIDO) == 1:
                count += 1

        diag1 = [m[0][0], m[1][1], m[2][2]]
        if diag1.count(jogador) == 2 and diag1.count(Tabuleiro.DESCONHECIDO) == 1:
            count += 1

        diag2 = [m[0][2], m[1][1], m[2][0]]
        if diag2.count(jogador) == 2 and diag2.count(Tabuleiro.DESCONHECIDO) == 1:
            count += 1

        return count

    def jogar_canto_oposto(self):
        opostos = {(0,0):(2,2), (0,2):(2,0), (2,0):(0,2), (2,2):(0,0)}
        for canto, oposto in opostos.items():
            i, j = canto
            oi, oj = oposto
            if self.matriz[i][j] == self.oponente and self.matriz[oi][oj] == Tabuleiro.DESCONHECIDO:
                return (oi, oj)
        return None

    def jogar_canto_vazio(self):
        cantos = [(0,0), (0,2), (2,0), (2,2)]
        for i, j in cantos:
            if self.matriz[i][j] == Tabuleiro.DESCONHECIDO:
                return (i, j)
        return None

    def jogar_qualquer(self):
        for i in range(3):
            for j in range(3):
                if self.matriz[i][j] == Tabuleiro.DESCONHECIDO:
                    return (i, j)
        return None
