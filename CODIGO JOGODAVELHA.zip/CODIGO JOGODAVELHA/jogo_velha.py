from tabuleiro_screen import TabuleiroScreen
from tabuleiro import Tabuleiro
from jogador_ia import JogadorIA
from jogador_humano import JogadorHumano


class JogoVelha:
    def __init__(self):
        self.screen = TabuleiroScreen()
        self.tabuleiro = Tabuleiro()
        self.jogadores = [
            JogadorHumano(self.tabuleiro, self.screen.buttons, Tabuleiro.JOGADOR_X),
            JogadorIA(self.tabuleiro, Tabuleiro.JOGADOR_0)
        ]
        self.id_jogador_corrente = 0
        self.jogador_corrente = self.jogadores[self.id_jogador_corrente]

    def troca_jogador(self):
        self.id_jogador_corrente = (self.id_jogador_corrente + 1) % 2
        self.jogador_corrente = self.jogadores[self.id_jogador_corrente]

    def start(self):
        self.screen.desenha_tabuleiro()

        while not self.acabou_jogo():
            jogada = self.jogador_corrente.getJogada()
            if jogada is None:
                continue

            linha, coluna = jogada

            # Verifica se já foi jogado
            if self.tabuleiro.matriz[linha][coluna] != Tabuleiro.DESCONHECIDO:
                continue  # ignora jogadas inválidas

            self.tabuleiro.matriz[linha][coluna] = self.jogador_corrente.tipo
            self.screen.update_text_button(linha, coluna, self.jogador_corrente.tipo)
            self.screen.desenha_tabuleiro()
            self.troca_jogador()

        # Fim do jogo — mostra resultado e espera fechar
        self.screen.desenha_tabuleiro()
        self.wait_quit_event()

    def acabou_jogo(self):
        resultado = self.tabuleiro.tem_campeao()
        if resultado != Tabuleiro.DESCONHECIDO:
            if resultado == Tabuleiro.JOGADOR_X:
                self.screen.resultado_txt = "X venceu!"
            elif resultado == Tabuleiro.JOGADOR_0:
                self.screen.resultado_txt = "O venceu!"
            else:
                self.screen.resultado_txt = "Empate!"
            return True

        # Verifica empate (se não há mais casas vazias)
        for linha in self.tabuleiro.matriz:
            if Tabuleiro.DESCONHECIDO in linha:
                return False  # Ainda há jogadas disponíveis

        self.screen.resultado_txt = "Empate!"
        return True

    def wait_quit_event(self):
        self.screen.wait_quit_event()
