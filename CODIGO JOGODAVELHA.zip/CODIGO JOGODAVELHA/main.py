from jogo_velha import JogoVelha

if __name__ == "__main__":
    jogo = JogoVelha()
    jogo.start()  # Inicia o loop do jogo
    jogo.wait_quit_event()