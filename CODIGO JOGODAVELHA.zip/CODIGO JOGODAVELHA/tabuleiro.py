class Tabuleiro:
    DESCONHECIDO = 0
    JOGADOR_0 = 1
    JOGADOR_X = 4

    def __init__(self):
        self.matriz = [
            [Tabuleiro.DESCONHECIDO for _ in range(3)]
            for _ in range(3)
        ]

    def tem_campeao(self):
        m = self.matriz
        for i in range(3):
            if m[i][0] == m[i][1] == m[i][2] != Tabuleiro.DESCONHECIDO:
                return m[i][0]
            if m[0][i] == m[1][i] == m[2][i] != Tabuleiro.DESCONHECIDO:
                return m[0][i]
        if m[0][0] == m[1][1] == m[2][2] != Tabuleiro.DESCONHECIDO:
            return m[0][0]
        if m[0][2] == m[1][1] == m[2][0] != Tabuleiro.DESCONHECIDO:
            return m[0][2]
        return Tabuleiro.DESCONHECIDO

    def esta_cheio(self):
        for linha in self.matriz:
            if Tabuleiro.DESCONHECIDO in linha:
                return False
        return True
