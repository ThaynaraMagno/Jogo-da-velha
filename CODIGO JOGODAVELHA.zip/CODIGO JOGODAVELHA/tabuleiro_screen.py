import pygame
import buttons as bt

class TabuleiroScreen:
    def __init__(self):
        self.resultado_txt = ""
        pygame.init()
        self.screen = pygame.display.set_mode((700, 700))
        pygame.display.set_caption("Jogo da Velha")
        self.screen.fill((255, 255, 255))

        self.buttons = [[], [], []]
        for i in range(3):
            for j in range(3):
                btn = bt.Button(self.screen, (50 + j*200, 50 + i*200), (180, 180))
                self.buttons[i].append(btn)

        self.desenha_tabuleiro()

    def desenha_tabuleiro(self):
        bt.buttons_v.update()
        bt.buttons_v.draw(self.screen)

        pygame.draw.line(self.screen, (0, 0, 0), (250, 50), (250, 650), 5)
        pygame.draw.line(self.screen, (0, 0, 0), (450, 50), (450, 650), 5)
        pygame.draw.line(self.screen, (0, 0, 0), (50, 250), (650, 250), 5)
        pygame.draw.line(self.screen, (0, 0, 0), (50, 450), (650, 450), 5)

        fg = pygame.Color("black")
        font = pygame.font.SysFont("Arial", 40)
        text_render = font.render(self.resultado_txt, True, fg)
        self.screen.blit(text_render, (250, 10))
        pygame.display.update()

    def update_text_button(self, x, y, player):
        self.buttons[x][y].change_text(player)

    def wait_quit_event(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
